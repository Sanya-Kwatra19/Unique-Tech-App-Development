import React from 'react'
import '../components/Page11.css'
import image42 from '../assets/image42.png'
import image43 from '../assets/image43.png'
import image44 from '../assets/image44.png'
import image45 from '../assets/image45.png'
import image46 from '../assets/image46.png'
import image47 from '../assets/image47.png'

function Page11() {
  return (
    <div>
      <div className='footer'>
        <div className='page11_text1'>PORTFOLIO</div>
        
        <ul className='portfolio_list'> 
            <li>Web Design</li>
            <li>Branding & Identity</li>
            <li>Mobile Design</li>
            <li>Print</li>
            <li>User Interface</li>
        </ul>
        
        <div className='page11_text2'>ABOUT</div>
        <ul className='about_list'>
            <li>The Company</li>
            <li>History</li>
            <li>Vision</li>
        </ul>
        
        <div className='page11_text3'>GALLERY</div>
        <ul className='gallery_list'>
            <li>Flickr</li>
            <li>Picasa</li>
            <li>iStockPhoto</li>
            <li>PhotoDune</li>
        </ul>
        
        <div className='page11_text4'>CONTACT US</div>
        <ul className='contact_list'>
            <li>Basic Info</li>
            <li>Map</li>
            <li>Contact Info</li>
        </ul>
        
        <img src={image42} className='page11_image1' />
        
        <img src={image42} className='page11_image2' />
        
        <img src={image42} className='page11_image3' />
        <img src={image42} className='page11_image4' />
        
        <img src={image43} className='page11_image5' />
        
        <img src={image44} className='page11_image6' />
        
        <img src={image45} className='page11_image7' />
        
        <img src={image46} className='page11_image8' />
        
       <img src={image47} className='page11_image9' />
  

      </div>
    </div>
  )
}

export default Page11
