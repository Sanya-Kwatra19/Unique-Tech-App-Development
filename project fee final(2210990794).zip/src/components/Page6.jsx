import React from 'react'
import '../components/Page6.css'
import image22 from '../assets/image22.png'
import image23 from '../assets/image23.png'
import image24 from '../assets/image24.png'
import image25 from '../assets/image25.png'

function Page6() {
  return (
    <div>
        <div id='page6' className='background6'>
            <img src={image22} className='page6_image1' />
            
            <img src={image23} className='page6_image2' />
            
            <div className='page6_text1'>OUR HISTORY</div>
            
            <img src={image24} className='page6_image3' />
            
            <img src={image25} className='page6_image4' />
            
            <p className='page6_text2'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Cupiditate, molestias ipsum consectetur itaque nemo labore, alias asperiores, quasi non magni et necessitatibus rem! Quibusdam consequatur nobis perferendis commodi accusantium tenetur!
            Ipsam maxime odio reiciendis ipsum animi est amet nam dignissimos ad laboriosam! Neque harum porro enim ratione pariatur recusandae exercitationem quo quia beatae quis. Tempore expedita inventore perferendis facilis! Tempora.
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Quibusdam tempore iste temporibus quidem.</p>
            
  <button className='page6_button'>BROWSE OUR STORY</button>

        </div>
      
    </div>
  )
}

export default Page6
