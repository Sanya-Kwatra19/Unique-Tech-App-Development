import React from 'react'
import '../components/Page7.css'
import image23 from '../assets/image23.png'
import image8 from '../assets/image8.png'
import image9 from '../assets/image9.png'
import image26 from '../assets/image26.png'
import image27 from '../assets/image27.png'
import image28 from '../assets/image28.png'

function Page7() {
  return (
    <div>
        <div className='background7'>
          
            <img src={image23} className='page7_image1' />
            
            <div className='page7_text1'>OUR BUSINESS REALTED PROJECTS</div>
            
            <img src={image8} className='page7_image2' />
            
            <img src={image9} className='page7_image3' />
            
            <img src={image26} className='page7_image4' />
            
            <img src={image27} className='page7_image5' />
            
            <img src={image28} className='page7_image6' />
            
            <div className='page7_text2'>TECHNICAL AID</div>
            
            <div className='page7_text3'>SECURE ACCESS</div>
            
            <div className='page7_text4'>MARKET RESEARCH</div>
            
            <div className='page7_text5'>CREDIT</div>
            
            <div className='page7_text6'>TARGETTING</div>
            
            <div className='page7_text7'>INSURANCE</div>
            
            <div className='page7_text8'>ECOMMERCE</div>
            <div className='page7_text9'>OFFICE</div>
  
  </div>
      
    </div>
  )
}

export default Page7
