import React from 'react'
import '../components/Page8.css'
import image23 from '../assets/image23.png'
import image5 from '../assets/image5.png'
import image6 from '../assets/image6.png'
import image29 from '../assets/image29.png'
import image30 from '../assets/image30.png'
import image31 from '../assets/image31.png'
import image32 from '../assets/image32.png'
import image33 from '../assets/image33.png'
import image34 from '../assets/image34.png'
import image35 from '../assets/image35.png'

function Page8() {
  return (
    <div>
      <div id='page8' className='background8'>
        <img src={image23} className='page8_image1' />
        
        <div className='page8_text1'>OUR TEAM MEMBERS</div>
        
        <img src={image6} className='page8_image2' />
        
        <img src={image5} className='page8_image3' />
        
        <img src={image29} className='page8_image4' />
        
        <img src={image30} className='page8_image5' />
        
        <img src={image30} className='page8_image6' />
        
        <img src={image30} className='page8_image7' />
        
        <img src={image30} className='page8_image8' />
        
        <img src={image30} className='page8_image9' />
        
        <img src={image31} className='page8_image10' />
        
        <img src={image32} className='page8_image11' />
        
        <img src={image33} className='page8_image12' />
        
        <img src={image34} className='page8_image13' />
        
        <img src={image35} className='page8_image14' />
        
        <div className='page8_text2'>SYED MIRAJ</div>
        
        <div className='page8_text7'>UI & UX DESIGNER</div>
      
        <div className='page8_text3'>PENNY HUSTON</div>
        
        <div className='page8_text8'>DEVELOPER</div>
        
        <div className='page8_text4'>LENNERD SHELLY</div>
        <div className='page8_text9'>REVIEWER</div>
        
        <div className='page8_text5'>SHELDON CUPPER</div>
        <div className='page8_text10'>MARKETTER</div>
        <div className='page8_text6'>ASHLEY COLE </div>
        <div className='page8_text11'>MANAGEMENT</div>
  
      </div>
    </div>
  )
}

export default Page8
