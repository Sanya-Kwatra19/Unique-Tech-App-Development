import React from 'react'
import '../components/Page2.css';
import image4 from '../assets/image4.png'
import image5 from '../assets/image5.png'
import image6 from '../assets/image6.png'
import image1 from '../assets/image1.png'
import image2 from '../assets/image2.png'
import '../components/Page3.jsx'
function Page2() {
  return (
    <div>
        <div id="page2"className='background2'>
         
            <img src={image4} className='page2_image1' />
           <div className='page2_text1'>WHAT WE DO</div>
           
            <img src={image5} className='page2_image2' />
          
            <img src={image6} className='page2_image3' />
               
            <img src={image1} className='page2_image4' />
            
            <img src={image2} className='page2_image5' />
            
            <div className='page2_text2'>WEB DESIGN</div>
            
            <div className='page2_text3'>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Saepe quasi sequi repudiandae esse eveniet itaque tempore veniam debitis animi nesciunt quia non, quod assumenda labore dolores facilis! Necessitatibus, laboriosam qui.</div>
            
            <div className='page2_text4'>Lorem ipsum dolor sit amet consectetur adipisicing elit. A corrupti excepturi cum fugiat minus facilis quo, porro optio? Quibusdam delectus cupiditate veniam, minima culpa illum repellendus officia magni deleniti </div>
            
            <button className='page2_button'>VIEW MORE</button>
            
            <div className='page2_text5'>SEARCH ENGINE OPTIMIZATION</div>
            
            <div className='page2_text6'>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Enim, quas doloremque cum consequatur non maxime consequuntur dolorem dolores obcaecati assumenda totam commodi, cupiditate quo labore velit, aperiam amet iure. Quaerat!</div>
  
            <div className='page2_text7'>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Magni illum unde corrupti odio sequi delectus itaque asperiores iste tempore optio illo labore commodi eum officia, molestiae distinctio sapiente. Impedit, nihil.</div>
            

            <button className='page2_button2'>VIEW MORE</button>
            
    
            <img src={image1} className='page2_image6' />
           
            <img src={image2} className='page2_image7' />
            

            <img src={image1} className='page2_image8' />
            
            <img src={image2} className='page2_image9' />
  
            <div className='page2_text8'>AFFILIATE MARKETING</div>
            
            <div className='page2_text9'>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Fugit ipsam ab, dignissimos suscipit natus consequatur facere reiciendis! Rerum accusamus soluta, sapiente explicabo reprehenderit iure molestiae voluptatum. Numquam optio asperiores fugit!</div>
            
            <div className='page2_text10'>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Autem in veniam dolorum, nostrum, sed aut est omnis, similique molestiae quas excepturi dicta voluptatum corporis dolore quae nihil tenetur accusamus repudiandae!</div>
            
  <button className='page2_button3'>VIEW MORE</button>
        </div>
    </div>
  )
}

export default Page2
