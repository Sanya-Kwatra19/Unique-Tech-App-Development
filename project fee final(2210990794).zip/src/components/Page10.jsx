import React from 'react'
import '../components/Page10.css'
import image38 from '../assets/image38.png'
import image39 from '../assets/image39.png'
import image40 from '../assets/image40.png'
import image41 from '../assets/image41.png'


function Page10() {
  return (
    <div>
      <div id='page10' className='background10'>
        <img src={image38} className='page10_image1' />
          
        <img src={image39} className='page10_image2' />
        
        <img src={image40} className='page10_image3' />
        
        <img src={image41} className='page10_image4' />
        
        <div className='page10_text1'>NEED CREATIVE WORKERS?</div>
        
        <button className='page10_button'>HIRE US </button>
        
      </div>
    </div>
  )
}

export default Page10
