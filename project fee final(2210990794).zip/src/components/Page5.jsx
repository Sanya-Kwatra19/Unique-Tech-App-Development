import React from 'react'
import '../components/Page5.css'
import image4 from '../assets/image4.png'
import image5 from '../assets/image5.png'
import image6 from '../assets/image6.png'
import image20 from '../assets/image20.png'
import image21 from '../assets/image21.png'

function Page5() {
  return (
    <div>
      <div id='page5' className='background5'>
        <img src={image4} className='page5_image1' />
        
        <div className='page5_text1'>OUR PACKAGES</div>
        
        <img src={image5} className='page5_image2' />
        
        <img src={image6} className='page5_image3' />
        
        <img src={image20} className='page5_image4'/>
        
        <img src={image20} className='page5_image5' />
        
        <img src={image21} className='page5_image6' />
        
        <img src={image21} className='page5_image7' />
        
        <img src={image21} className='page5_image8' />
        
        <img src={image21} className='page5_image9' />
        
        <div className='basic'>
            <div className='b_text1'>Basic</div>
            <div className='b_text2'>5  web sites</div>
            <div className='b_text3'>15  e-mails</div>
            <div className='b_text4'>5  my SQL databases</div>
            <div className='b_text5'>$ 5/mo.</div>
            <button className='b_button'>ORDER NOW</button>
        </div>
        <div className='standard'>
            <div className='s_text1'>Standard</div>
            <div className='s_text2'>15  web sites</div>
            <div className='s_text3'>40  e-mails</div>
            <div className='s_text4'>20  my SQL databases</div>
            <div className='s_text5'>$ 12/mo.</div>
            <button className='s_button'>ORDER NOW</button>
        </div>
        
        <div className='premium'>
            <div className='p_text1'>Premium</div>
            <div className='p_text2'>30  web sites</div>
            <div className='p_text3'>50  e-mails</div>
            <div className='p_text4'>40  my SQL databases</div>
            <div className='p_text5'>$ 19/mo.</div>
            <button className='p_button'>ORDER NOW</button>
        </div>
  
        
      </div>
    </div>
  )
}

export default Page5
