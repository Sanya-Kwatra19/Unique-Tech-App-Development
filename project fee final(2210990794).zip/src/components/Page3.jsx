import React from 'react'
import '../components/Page3.css';
import image7 from '../assets/image7.png'
import image8 from '../assets/image8.png'
import image9 from '../assets/image9.png'
import image10 from '../assets/image10.png'

function Page3() {
  return (
    <div>
      <div id='page3' className='background3'>
        <img src={image7} className='page3_image1' />
        
        <div className='page3_text1'>HOW WE WORK</div>
       
        <img src={image8} className='page3_image2' />
         
        <img src={image9} className='page3_image3' />
        
        <img src={image10} className='page3_image4' />
  
      </div>
    </div>
  )
}

export default Page3
