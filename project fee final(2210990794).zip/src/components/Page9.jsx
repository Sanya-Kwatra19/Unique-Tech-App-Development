import React from 'react'
import '../components/Page9.css'
import image23 from '../assets/image23.png'
import image8 from '../assets/image8.png'
import image9 from '../assets/image9.png'
import image36 from '../assets/image36.png'
import image37 from '../assets/image37.png'


function Page9() {
  return (
    <div>
      <div id='page10' className='background9'>
        <img src={image23} className='page9_image1' />
        
        <div className='page9_text1'>UPDATES & SUPPORT</div>
        
        <img src={image8} className='page9_image2' />
        
        <img src={image9} className='page9_image3' />
        
        <img src={image36} className='page9_image4' />
        
        <img src={image37} className='page9_image5' />
        
        <p className='page9_text2'>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Delectus autem quos asperiores pariatur. Ut impedit dolore ipsum soluta vel, consequuntur sint quod dolorum, aliquam optio deleniti quos nesciunt dolor sequi!
        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Vitae consectetur maxime nam qui, eos recusandae reprehenderit excepturi totam, amet labore praesentium aliquid, odio doloribus delectus? Ut, minus quasi! Reprehenderit, qui.</p>
        
        <button className='page9_button'>SUPPORT CENTER</button>
  
       
      </div>
    </div>
  )
}

export default Page9
