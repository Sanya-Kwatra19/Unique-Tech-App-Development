import React from 'react'
import '../components/Navbar.css'
import shape7 from '../assets/Shape 7.png'
import shape8 from '../assets/Shape8.png'
import image1 from '../assets/image1.png'
import image2 from '../assets/image2.png'
import image3 from '../assets/image3.png'
import '../components/Page2.jsx'
import '../components/Page3.jsx'
import '../components/Page4.jsx'
import '../components/Page5.jsx'
import '../components/Page6.jsx'
import '../components/Page7.jsx'
import '../components/Page8.jsx'
import '../components/Page9.jsx'
import '../components/Page10.jsx'
import '../components/Page11.jsx'

function Navbar() {
  return (
    <div>
      <div className='background'>
        <div className='navbar'>
           <div className='rect_box'>
            <div className='logo'>UNIQUE</div>

           </div>
           <div className='logo2'>TECH</div>
          <a href="#page2" className='home'>HOME</a>
          <a href="#page3" className='services'>SERVICES</a>
          <a href="#page5" className='about'>ABOUT</a>
          <a href="#page6" className='portfolio'>PORTFOLIO</a>
          <a href="#page8" className='academic'>ACADEMIC</a>
          <a href="#page9" className='blog'>BLOG</a>
          <a href="#page10" className='contact_us'>CONTACT US</a>

        </div>
        <div className='page1_text1'>UNIQUE-TECH</div>
        <div className='page1_text2'>APP DEVELOPMENT</div>
        
        <div className='page1_text3'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui itaque voluptatibus numquam placeat explicabo ipsa unde quia maxime quibusdam labore consectetur neque, corporis optio magnam sit minus nisi eligendi aperiam</div>
        
        <div className='page1_text4'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Laborum esse dolore magnam explicabo sint laudantium, iusto ea reprehenderit aut consectetur temporibus a qui, perferendis ratione adipisci voluptatem, dolores rerum corrupti!</div>
        <button className='page1_button'>View More</button>
  
        <img src={shape7} className='page1_image1'/>
        <img src={shape8} className='page1_image2'/>
        <img src={image1} className='page1_image3' />
        <img src={image2} className='page1_image4' />
        <img src={image3} className='page1_image5' />
      </div>
    </div>
  )
}

export default Navbar
