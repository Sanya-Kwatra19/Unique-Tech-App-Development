import React from 'react'
import '../components/Page4.css';
import image4 from '../assets/image4.png'
import image6 from '../assets/image6.png'
import image5 from '../assets/image5.png'
import image11 from '../assets/image11.png'
import image12 from '../assets/image12.png'
import image13 from '../assets/image13.png'
import image14 from '../assets/image14.png'
import image15 from '../assets/image15.png'
import image16 from '../assets/image16.png'
import image17 from '../assets/image17.png'
import image18 from '../assets/image18.png'
import image19 from '../assets/image19.png'

function Page4() {
  return (
    <div>
      <div id='page4' className='background4'>
        <img src={image4} className='page4_image1' />
        
        <div className='page4_text1'>OUR FEATURES</div>
        
        <img src={image6} className='page4_image2' />
       
        <img src={image5} className='page4_image3' />
         
        <div className='pages'>
            <div className='visual_composer'>
                
                <img src={image11} className='notes_image'/>

                 <div className='vc_text1'>Visual Composer</div>
                  <p className='vc_text2'>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deleniti iure facere obcaecati illo, minus aliquam distinctio </p>
                 </div>
            <div className='responsive'>
                <img src={image12} className='tv_image' />
                <div className='rc_text1'>Responsive</div>
                <p className='rc_text2'>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deleniti iure facere obcaecati illo, minus aliquam distinctio</p>
            </div>
            <div className='retina_ready'>
                <img src={image13} className='rr_image' />
                <div className='rr_text1'>Retina Ready</div>
                <p className='rr_text2'>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deleniti iure facere obcaecati illo, minus aliquam distinctio</p>
            </div>
            
            <div className='typography'>
                <img src={image14} className='ty_image' />
                <div className='ty_text1'>Typography</div>
                <p className='ty_text2'>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deleniti iure facere obcaecati illo, minus aliquam distinctio</p>
            </div>
            
            <div className='theme_panel'>
                <img src={image15} className='tp_image' />
                <div className='tp_text1'>Theme Options Panel</div>
                <p className='tp_text2'>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deleniti iure facere obcaecati illo, minus aliquam distinctio</p>
            </div>
            
            <div className='dummy_content'>
                <img src={image16} className='dc_image' />
                <div className='dc_text1'>Dummy Content</div>
                <p className='dc_text2'>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deleniti iure facere obcaecati illo, minus aliquam distinctio</p>
            </div>
            
            <div className='many_style'>
                <img src={image17} className='ms_image' />
                <div className='ms_text1'>Many Styles Available</div>
                <p className='ms_text2'>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deleniti iure facere obcaecati illo, minus aliquam distinctio</p>
            </div>
            
            <div className='header_style'>
                <img src={image18} className='hs_image' />
                <div className='hs_text1'>Header Styles</div>
                <p className='hs_text2'>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deleniti iure facere obcaecati illo, minus aliquam distinctio</p>
            </div>
            
            <div className='icons'>
                <img src={image19} className='ic_image' />
                <div className='ic_text1'>10000 + icons</div>
  <p className='ic_text2'>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Deleniti iure facere obcaecati illo, minus aliquam distinctio</p>
  
  </div>
  </div>
      </div>
    </div>
  )
}

export default Page4
